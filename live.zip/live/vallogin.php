<?php
include("rb.php");
R::setup("mysql:host=localhost;dbname=live","root","");
// include("dataclass.php");

$email=$_GET['email'];
$pasword=$_GET['pasword'];

if($email==null){
    $nameerror="Please Fill Field";

    header("Location:login.php?msg=$nameerror&psddata=$pasword");
}

if($email!=null&&$pasword!=null){
$a=R::dispense('user');
$a->email=$email;
$a->pass=$pasword;
$a->msg="msg";
R::store($a);
}

$d = R::load('user',2);
echo $d->email;

// $data=R::findAll("user");
// foreach($data as $data)
// {
//     echo "Email".$data->email;
//     echo "<br>";

// }





// $obj=new data();
// $obj->setconnection();
// $obj->insert($email,$pasword);


