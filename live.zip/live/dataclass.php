<?php

include("db.php");

class data extends db{
    private $email;
    private $pass;

    function __construct(){
        // echo " Working";
    }

    function insert($email,$pass){
        $this->email=$email;
        $this->pass=$pass;

        $q="INSERT INTO user(id,email,pass,msg)VALUES('','$email','$pass','msg')";

        if($this->connection->exec($q)){
            header("Location:login.php");
        }
        
    }
}