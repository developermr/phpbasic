<?php

print "Hello";
echo "<br>";
echo "2nd method";
echo "<br>";
//indexed array

$cars[0]="Suzuki";
$cars[1]="Honda";
$cars[1]="Audi";


$laptops=array("Dell",0,"Apple");
print $laptops[0];
echo "<br>";
for ($i=0;$i<2;$i++){
    echo $cars[$i];
    echo "<br>";
}

// foreach($cars as $cars){
//     echo "<br>";
//     echo $cars;
// }

//associative array

$marks["saif"]=10;
$marks["salman"]=5;
$marks["sidra"]=9;
$marks["kamran"]=5;


foreach($marks as $marks=>$values){
    echo $marks;
    echo $values;
    echo "<br>";

}

