<?php








$url="api.airvisual.com/v2/city?city=Lahore&state=Punjab&country=Pakistan&key=558bf60f-029c-430c-aad0-ff5cda5a82b7";

$airvisual = curl_init($url);
curl_setopt($airvisual, CURLOPT_RETURNTRANSFER,true);
$json_data = curl_exec($airvisual);
$json_array = json_decode($json_data, true);


$temperature= "Temperature : ".$json_array['data']['current']['pollution']['aqius'];
$city= "City: ".$json_array['data']['city'];
$state= "State: ".$json_array['data']['state'];
$cordinate="cordinate: ". $json_array['data']['location']['coordinates'][0];
// echo $json_array['data']['location']['coordinates'][1];

require('fpdf.php');
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(10,10,$city);
$pdf->Cell(10,30,$state);
$pdf->Cell(10,50,$cordinate);
$pdf->Cell(10,70,$temperature);
$pdf->Output();

