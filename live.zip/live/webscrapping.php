<?php
$url="api.airvisual.com/v2/city?city=Lahore&state=Punjab&country=Pakistan&key=558bf60f-029c-430c-aad0-ff5cda5a82b7";

$airvisual = curl_init($url);
curl_setopt($airvisual, CURLOPT_RETURNTRANSFER,true);
$json_data = curl_exec($airvisual);

$json_array = json_decode($json_data, true);

// echo "working";